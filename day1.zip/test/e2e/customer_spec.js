//testsuite
describe('customer module tests', function() {
  
  it('should have five customers', function() {
    browser.get('http://localhost:8080/first.html');
   	var customerlist = element.all(by.repeater('customer in customers'));
   	expect(customerlist.count()).toEqual(5);
  });

  it('should delete a customer', function() {
    browser.get('http://localhost:8080/first.html');
   	var customerlist = element.all(by.repeater('customer in customers'));
   	customerlist.get(2).element(by.css('.cardClose')).click();
   	browser.pause();
   	expect(customerlist.count()).toEqual(4);
  });

});