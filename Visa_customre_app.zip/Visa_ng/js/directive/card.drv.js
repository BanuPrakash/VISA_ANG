(function(){
	var ng = angular.module("directive_module",[]);
	ng.directive("cardView", function() {
		return {
			templateUrl : 'js/template/card.templ.html',
			restrict : 'EA',
			scope : {
				first : '=',
				second : '=',
				pic : '=',
				info : '=',
				delete : '&',
				openEdit : '&'
			}
		}
		
	});
})();