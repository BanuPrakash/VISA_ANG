(function(){
	var ng = angular.module("service_module",[]);
	ng.service("CustomerService", function($http,$q){
		this.getCustomers = function() {
			var deferred = $q.defer();
			$http.get("/customers").then(function(data){
					deferred.resolve(data);
				},
				function(data) {
					deferred.reject(data);
				}
			);
			return deferred.promise;
		};

		this.deleteCustomer = function(id) {
			$http.delete("/customers/" +id);
		};

		this.updateCustomer = function(id, customer) {
			$http.put("/customers/" +id, customer);
		};


		this.getOrders = function() {
			var deferred = $q.defer();
			$http.get("/orders").then(function(data){
					deferred.resolve(data);
				},
				function(data) {
					deferred.reject(data);
				}
			);
			return deferred.promise;
		};
	});
})();