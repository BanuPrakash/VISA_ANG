(function(){
	var ng = angular.module("customer_module", ["directive_module","service_module"]);

	ng.controller("CustomerMenuController", function($rootScope, $scope){
		$scope.searchText ="";
		$scope.filterCustomers = function() {
			$rootScope.$broadcast("filter_event",$scope.searchText);
		}
	});

	ng.controller("CustomerListController", function($scope, CustomerService){
		
		CustomerService.getCustomers().then(function(result){
			$scope.customers = customers = result.data;
		});
		
		$scope.editMode = false;
		$scope.openEdit = function(customer) {
			$scope.current = customer;
			$scope.editMode = true;
		}

		$scope.update = function() {
			$scope.editMode = false;
			//write to backend
			CustomerService.updateCustomer($scope.current.id, $scope.current);
		}

		$scope.$on("filter_event", function(evt, txt){
			var result = [];
			customers.forEach(function(c){
				if(c.firstName.toUpperCase().indexOf(txt.toUpperCase()) >=0 ||
					c.lastName.toUpperCase().indexOf(txt.toUpperCase()) >=0 ) {
					result.push(c);
				}
			});
			$scope.customers = result;
		});


		$scope.deleteCustomer = function(id) {
			var idx =-1;
			$scope.customers.forEach(function(customer, index){
				if(customer.id == id) {
					idx = index;
					CustomerService.deleteCustomer(customer.id);
				}
			});
			if(idx >= 0) {
				$scope.customers.splice(idx,1);
			}
		}
	});

})();